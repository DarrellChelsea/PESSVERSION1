<?php
define('DB_USER', "root"); 
define('DB_PASSWORD', ""); 
define('DB_DATABASE', "darrell_pessdb"); 
define('DB_SERVER', "localhost"); 