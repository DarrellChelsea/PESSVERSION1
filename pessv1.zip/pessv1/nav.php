<div id="banner"><img src="banner.png"></div>
<div class="topnav">
	 <a href="logcall1.php">Log Call</a>
	<a href="update.php">Updates</a>
	<a href="#">Report</a>
	<a href="#">History</a>
</div>